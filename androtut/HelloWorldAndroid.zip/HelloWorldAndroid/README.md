# Bare-bones Hello World Android app (Java)

This project intentionally uses no AndroidX libraries and no external app dependencies.
The UI is created directly in `MainActivity.java`, so there is no layout XML.

## Requirements

- JDK 17
- Gradle installed on your machine (used once to create the wrapper)
- Android SDK with Android SDK Platform 35 installed
- Android SDK Build-Tools installed (Android Studio's SDK Manager can install these)

Android Gradle Plugin 8.7.3 is configured, which uses Gradle 8.9 and JDK 17.

## 1. Create the Gradle wrapper using your installed Gradle

Open a terminal and `cd` into this project directory, the one containing `settings.gradle`.

Check Java and Gradle:

```bash
java -version
gradle --version
```

Use JDK 17. Then generate the wrapper:

```bash
gradle wrapper --gradle-version 8.9
```

This creates `gradlew`, `gradlew.bat`, and the `gradle/wrapper/` files. The first wrapper build may download Gradle 8.9, so an internet connection may be required.

If your installed Gradle is too old to run the `wrapper` task or cannot parse this project's build files, run the wrapper task from a minimal temporary directory (see below), or install/use a newer Gradle version.

## 2. Build the debug APK

From the project root:

```bash
./gradlew assembleDebug
```

On Linux, if necessary, make the script executable first:

```bash
chmod +x gradlew
./gradlew assembleDebug
```

The APK will be created at:

`app/build/outputs/apk/debug/app-debug.apk`

## 3. Install on a connected Android phone (optional)

Enable USB debugging, connect the phone, then run:

```bash
./gradlew installDebug
```

Or copy `app/build/outputs/apk/debug/app-debug.apk` to the phone and install it manually.

## If your installed Gradle is too old to generate the wrapper

Create a temporary empty directory and put this in a file named `build.gradle`:

```groovy
tasks.register('wrapper', Wrapper) {
    gradleVersion = '8.9'
    distributionType = Wrapper.DistributionType.BIN
}
```

Then run:

```bash
gradle -b build.gradle wrapper
```

Copy the generated `gradlew`, `gradlew.bat`, and `gradle/wrapper/` directory into the HelloWorldAndroid project root. Then run `./gradlew assembleDebug`.

## SDK location

Gradle usually finds the Android SDK automatically if Android Studio or the SDK command-line tools are installed. If not, create `local.properties` in the project root, using your actual SDK path, for example:

```properties
sdk.dir=/home/YOUR_USER/Android/Sdk
```

Replace the example path with the real location on your machine. Do not share `local.properties` if it contains machine-specific paths.
