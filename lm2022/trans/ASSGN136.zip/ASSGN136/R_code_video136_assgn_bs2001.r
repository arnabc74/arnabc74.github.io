x1=1:100
x2=3*x1 + rnorm(100)/10
x3=x1*x1
tmp=c()
for(i in 1:100){
y = 1+2*x1+0.05*x3+4*rnorm(100)
tmp=rbind(tmp, lm(y~x1+x2+x3)$coef)}
library(MASS)
fit = lm.ridge(y~x1+x2+x3,lambda=seq(0,2,len=200))
matplot(fit$lambda,coef(fit)[,-1],ty='l')
coef(fit)
select(fit)